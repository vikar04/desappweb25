<?php require "assets/config.php"?>
<?php include "bloques/header.php"?>
<?php
    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $sql = "SELECT * FROM $tablename WHERE id=$id;";
        

        //Realizar Consulta a la Base de Datos
        $result = consulta($sql,1);

        // Chequear si hay resultados
        if (mysqli_num_rows($result) > 0) {
            // Mostrar los datos de cada fila
            while($alumno = mysqli_fetch_assoc($result)) {
            echo '<div class="alumn_ficha">';
            echo '<img class="inf_alumn" src="assets/img/alumn/' . $alumno['foto'] . '" alt="foto_de_'.$alumno['nombre'].'">';
            echo '<div class="alumn_datos"><h3 class="nombre">'.$alumno['nombre'] .' '.$alumno['apellidos'].'</h3>';
            echo '<a href="tel:'.$alumno['telefono'].'">'.$alumno['telefono'].'</a>';
            echo '</div></div>';      }
        } else {
            echo "No tenemos datos sobre este alumno.";
        }
        }
        
        else{
          echo "No se ha pasado el identicador del alumno. Regrese a: Alumnos <a href='alumnos.php'>haciendo click aquí</a> y vuelva a entar en una ficha.";
        }
        
?>

<?php include "bloques/footer.php"?>