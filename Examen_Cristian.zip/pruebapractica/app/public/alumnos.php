<?php require "assets/config.php"?>
<?php include "bloques/header.php"?>

<h2>Lista de alumnos matriculados</h2>


<ul id="listaAlumnos" class="lista_al">

<?php
$table = "alumnos";
$sql = "SELECT id, foto, nombre, apellidos, telefono FROM $table;";

$result = consulta($sql,1);

if (mysqli_num_rows($result) > 0) {
    
    while($alumno = mysqli_fetch_assoc($result)) {
    echo '<li>';
    echo '<img class="foto_al" src="assets/img/alumn/' . $alumno['foto'] . '" alt="">';
    echo '<h3 class="nombre">'.$alumno['nombre'] .' '.$alumno['apellidos'].'</h3>';
    echo '<p class="tel">'.$alumno['telefono'].'</p>';
    echo '<a class="btn" href="alumno.php?id='.$alumno['id'].'">Ver más info</a>';
    echo '</li>';}
} else {
    echo "El registro de alumnos esta vacio. Haga su matricula en instalacion.";
}

?>
</ul>

<?php include "bloques/footer.php"?>