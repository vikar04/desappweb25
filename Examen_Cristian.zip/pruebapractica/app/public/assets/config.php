<?php
// Instalación en el servidor
const URL= 'http://pruebapractica.local';

// Datos de conexión con la base de datos
const HOST ='localhost';
const USER  ='root';
const PASS  ='root';
const DBNA  ='academia';

$tablename = 'alumnos';

const TITULO_SITE='MyAcademy';
const DESCRIPCION='Sistema para la administracion de alumnos en la plataforma de MyAcademy';

  const DATOS_MENUPRINCIPAL=[
    //  0.nombre     1.url        2.target    3.class         4.titulo
      ['Alumnos',   'alumnos.php',    0,      '',             'Alumnos'],
      ['Matricular',  'insertar.php',   0,      '',             'Insertar'],
  ];
  const DATOS_MENULEGAL=[
      //  0.nombre                  1.url              2.target  3.class  4.titulo
        ['Aviso legal',             'avisolegal.php',  0,        '',      ''],
        ['Politica de cookies',     'cookies.php',     0,        '',      ''],
        ['Politica de privacidad',  'privacidad.php',  0,        '',      '']
  ];


  // Constructor de títulos
function titulo() {
    global $titulo;
    echo (isset($titulo) ? $titulo.' - ' : '') . TITULO_SITE;
  }

  // Constructor de menús
  function menu($array=DATOS_MENUPRINCIPAL){
    echo '<nav>
    <ul class="menu">';
        
       foreach($array as $item){
        
        echo "<li><a href='".URL."/$item[1]' class='$item[3]' title='$item[4] '";
        //si target=1 poner blank
         if($item[2]){ 
            echo " target='_blank'";     
         } 
            
        echo ">$item[0]</a></li>";
    }
    echo '</ul></nav>';
    }

    function consulta($sql, $devolver=false, $mensaje="La consulta se ha realizado correctamente"){
   
        // Crear conexión
        $conn = mysqli_connect(HOST, USER, PASS, DBNA);
    
        // Chequear coneción
        if (!$conn) { die("Conexión fallida: " . mysqli_connect_error()); }
    
        //Realizar Consulta a la Base de Datos
        $resultado = mysqli_query($conn, $sql);
        
        if($devolver){
            return $resultado;
        }
        else{
            if (mysqli_query($conn, $sql)) {
                echo "<h2>$mensaje</h2>";
                } else {
                echo "Error al realizar la consulta:" . mysqli_error($conn);
                }
        }
    
        //Cerramos conexión
        mysqli_close($conn);
    }
    

?>