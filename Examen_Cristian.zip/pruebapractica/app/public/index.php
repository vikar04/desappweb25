<?php require "assets/config.php"?>
<?php include "bloques/header.php"?>

<h1>Bienvenidos a MyAcademy</h1>

<p>En <strong>MyAcademy</strong>, ofrecemos formación de calidad en diversas áreas, con el objetivo de ayudarte a alcanzar tus metas académicas y profesionales. Ya sea que estés buscando mejorar tus habilidades o comenzar un nuevo curso, aquí encontrarás el apoyo y los recursos que necesitas.</p>

<section>
    <h2>Nuestros Servicios</h2>
    <div class="servicios">
        <div class="serv">
            <h3>Cursos Presenciales</h3>
            <p>Impartimos cursos presenciales en distintas materias como matemáticas, programación, idiomas, y más.</p>
        </div>
        <div class="serv">
            <h3>Cursos Online</h3>
            <p>Accede a nuestros cursos en línea desde cualquier lugar del mundo, con material interactivo y clases grabadas.</p>
        </div>
        <div class="serv">
            <h3>Clases Particulares</h3>
            <p>Ofrecemos clases particulares adaptadas a tus necesidades. Si prefieres una atención más personalizada, esta es tu opción.</p>
        </div>
    </div>
</section>

<?php
?>