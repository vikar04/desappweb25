<?php require "assets/config.php"?>
<?php $titulo= "Insertar Alumno Nuevo en la Base de 
datos"?>
<?php include "bloques/header.php"?>

<section id="agregar">
    <h2>Agregar Nuevo Alumno</h2>
    <form action="insertar_alumno.php" method="POST" enctype="multipart/form-data">

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="apellidos">Apellidos:</label>
        <input type="text" id="apellidos" name="apellidos" required>

        <label for="telefono">Teléfono:</label>
        <input type="tel" id="telefono" name="telefono" required>

        <label for="foto">Foto:</label>
        <input type="file" id="foto" name="foto" accept="image/*">

        <button type="submit">Insertar Alumno</button>
    </form>
</section>

<?php include "bloques/footer.php"?>