</main>
<footer>
    <? menu() ?>
    <p>&copy; Copyright <?=date('Y')?> - <?=$titulo?></p>
    <? menu(DATOS_MENULEGAL) ?>
</footer>
</body>
</html>